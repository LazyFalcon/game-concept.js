<template>
  <div id="app">
    <TopBar/>
    <MainView/>
    <LeftBar/>
  </div>
</template>

<script>
import MainView from './components/MainView'
import LeftBar from './components/LeftBar'
import TopBar from './components/TopBar'

export default {
  name: 'App',
  components: {
    MainView,
    LeftBar,
    TopBar
  }
}
</script>

<style>
#app {
  font-family: 'Segoe UI', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
