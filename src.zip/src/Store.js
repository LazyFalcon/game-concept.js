import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    /*
    * stores currently selected object of any type, type specific behaviors should be provided by traits and template selection
    * common props:
    *   name
    *   type
     */
    selectedObject: undefined
  },
  mutations: {
    selectObject (state, payload) {
      console.log('selected: ', payload)
      if (payload.object === this.selectedObject) this.state.selectedObject = undefined
      else this.state.selectedObject = payload.object
    },
    unselect (state) {
      this.state.selectedObject = undefined
    }
  }
})
